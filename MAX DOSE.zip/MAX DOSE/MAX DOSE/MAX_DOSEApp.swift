//
//  MAX_DOSEApp.swift
//  MAX DOSE
//
//  Created by admin on 3/11/23.
//

import SwiftUI

@main
struct MAX_DOSEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
