//
//  WeightInterfaceController.swift
//  Max Dose WatchKit Extension
//
//  Created by AkifBilal on 16/04/2022.
//

import WatchKit
import Foundation


class WeightInterfaceController: WKInterfaceController {

    var selectedMenu = 0
    var selectedWeight = 0.0
    
    @IBOutlet weak var txtWeight: WKInterfaceTextField!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        self.selectedMenu = context as? Int ?? 0
    }

    override func willActivate() {
        super.willActivate()
    }

    override func didDeactivate() {
        super.didDeactivate()
    }
    
    @IBAction func textFieldAction(_ value: String){
        selectedWeight = Double(value) ?? 0.0
    }

    @IBAction func btnNextAction() {
        if(selectedWeight != 0.0){
            let dict = ["selectedMenu" : selectedMenu, "selectedWeight" : selectedWeight] as? [String : Any]
            pushController(withName: "AdultOrChildInterfaceController", context: dict)
        }
    }
}
