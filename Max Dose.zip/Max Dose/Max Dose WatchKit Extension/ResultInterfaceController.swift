//
//  ResultInterfaceController.swift
//  Max Dose WatchKit Extension
//
//  Created by AkifBilal on 16/04/2022.
//

import WatchKit
import Foundation


class ResultInterfaceController: WKInterfaceController {

    var selectedValues :  [String:Any] = [:]
    
    var adultOrChild = ""
    var selectedMenu = 0
    var selectedWeight = 0.0
    
    @IBOutlet weak var lblResult: WKInterfaceLabel!
    @IBOutlet weak var lblSummary: WKInterfaceLabel!
    @IBOutlet weak var lblFormula: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        selectedValues = context as? [String:Any] ?? [:]
        
        selectedMenu = selectedValues["selectedMenu"] as? Int ?? 0
        selectedWeight = selectedValues["selectedWeight"] as? Double ?? 0.0
        adultOrChild = selectedValues["AdultOrChild"] as? String ?? ""
    }

    override func willActivate() {
        super.willActivate()
        
        self.calculateResult()
    }

    override func didDeactivate() {
        super.didDeactivate()
    }
    
    func calculateResult(){
        if(selectedMenu == 1){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 36
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/36")
                    lblResult.setText("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/36")
                    lblResult.setText(String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 36
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/36")
                    lblResult.setText("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/36")
                    lblResult.setText(String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 500mg /11 carp\nMax for Kids: 300mg")
        } else if(selectedMenu == 2){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 36
                if(val > 5.5){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/36")
                    lblResult.setText ("5.5 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/36")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 36
                if(val > 5.5){
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/36")
                    lblResult.setText ("5.5 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/36")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 500mg/ 5.5 carps\nMax for Kids: 300mg")
        } else if(selectedMenu == 3){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 36
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/36")
                    lblResult.setText ("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/36")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 36
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/36")
                    lblResult.setText ("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/36")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 400mg /11 carp\nMax for Kids: 300mg")
        } else if(selectedMenu == 4){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 54
                if(val > 7){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/54")
                    lblResult.setText ("7 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/54")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 54
                if(val > 7){
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/54")
                    lblResult.setText ("7 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 2.0)/54")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 400mg /7 carp\nMax for Kids: 300mg")
        } else if(selectedMenu == 5){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight)) / 9
                if(val > 10){
                    lblFormula.setText("Used Formula\n(Weight)/9")
                    lblResult.setText ("10 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight)/9")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 0.6) / 9
                if(val > 10){
                    lblFormula.setText("Used Formula\n(Weight * 0.6)/9")
                    lblResult.setText ("10 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 0.6)/9")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 90mg /10 carp\nMax for Kids: 90mg")
        } else if(selectedMenu == 6){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText ("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText ("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: Det by wt\nMax for Kids: 500mg")
        } else if(selectedMenu == 7){
            if(adultOrChild == "Adult"){
                lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText ("11 Carpules")
                } else {
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText ("11 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 3.2)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Kids: 2.0mg/ lb , 300mg")
        } else if(selectedMenu == 8){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 4.0) / 72
                if(val > 8){
                    lblFormula.setText("Used Formula\n(Weight * 4.0)/72")
                    lblResult.setText ("8 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 4.0)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 2.7) / 72
                if(val > 8){
                    lblFormula.setText("Used Formula\n(Weight * 2.7)/72")
                    lblResult.setText ("8 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 2.7)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 600mg/8 carp\nMax for Kids:400mg")
        } else if(selectedMenu == 9){
            if(adultOrChild == "Adult"){
                let val = (Double(selectedWeight) * 4.0) / 72
                if(val > 8){
                    lblFormula.setText("Used Formula\n(Weight * 4.0)/72")
                    lblResult.setText ("8 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 4.0)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            } else {
                let val = (Double(selectedWeight) * 2.7) / 72
                if(val > 8){
                    lblFormula.setText("Used Formula\n(Weight * 2.7)/72")
                    lblResult.setText ("8 Carpules")
                } else {
                    lblFormula.setText("Used Formula\n(Weight * 2.7)/72")
                    lblResult.setText (String(format: "%.1f", val) + " Carpules")
                }
            }
            lblSummary.setText ("Max for Adults: 600mg/8 carp\nMax for Kids:400mg")
        }
    }
}
