//
//  AdultOrChildInterfaceController.swift
//  Max Dose WatchKit Extension
//
//  Created by AkifBilal on 16/04/2022.
//

import WatchKit
import Foundation

class AdultOrChildInterfaceController: WKInterfaceController {

    var selectedValues :  [String:Any] = [:]
    var adultOrChild = "Adult"
    
    var selectedMenu = 0
    var selectedWeight = 0.0
    
    @IBOutlet weak var btnAdult: WKInterfaceButton!
    @IBOutlet weak var btnChild: WKInterfaceButton!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        selectedValues = context as? [String:Any] ?? [:]
        
        selectedMenu = selectedValues["selectedMenu"] as? Int ?? 0
        selectedWeight = selectedValues["selectedWeight"] as? Double ?? 0.0
    }

    override func willActivate() {
        super.willActivate()
        
        btnAdult.setTitleWithColor(title: "Adult", color: .green)
        btnChild.setTitleWithColor(title: "Child", color: .white)
    }

    override func didDeactivate() {
        super.didDeactivate()
    }

    @IBAction func btnAdultAction() {
        adultOrChild = "Adult"
        btnAdult.setTitleWithColor(title: "Adult", color: .green)
        btnChild.setTitleWithColor(title: "Child", color: .white)
    }
    
    @IBAction func btnChildAction() {
        adultOrChild = "Child"
        btnAdult.setTitleWithColor(title: "Adult", color: .white)
        btnChild.setTitleWithColor(title: "Child", color: .green)
    }
    
    @IBAction func btnNextAction() {
        let dict = ["selectedMenu" : selectedMenu, "selectedWeight" : selectedWeight, "AdultOrChild" : adultOrChild] as? [String : Any]
        pushController(withName: "ResultInterfaceController", context: dict)
    }
}

extension WKInterfaceButton {
    func setTitleWithColor(title: String, color: UIColor) {
        let attString = NSMutableAttributedString(string: title)
        attString.setAttributes([NSAttributedString.Key.foregroundColor: color], range: NSMakeRange(0, attString.length))
        self.setAttributedTitle(attString)
    }
}
