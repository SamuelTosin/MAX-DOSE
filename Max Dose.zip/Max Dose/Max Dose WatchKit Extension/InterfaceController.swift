//
//  InterfaceController.swift
//  Max Dose WatchKit Extension
//
//  Created by AkifBilal on 15/04/2022.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
    }
    
    override func willActivate() {
    }
    
    override func didDeactivate() {
    }

    @IBAction func btnFirstAction() {
        self.moveToWeightController(vale: 1)
    }
    
    @IBAction func btnSecondAction() {
        self.moveToWeightController(vale: 2)
    }
    
    @IBAction func btnThirdAction() {
        self.moveToWeightController(vale: 3)
    }
    
    @IBAction func btnForthAction() {
        self.moveToWeightController(vale: 4)
    }
    
    @IBAction func btnFifthAction() {
        self.moveToWeightController(vale: 5)
    }
    
    @IBAction func btnSixAction() {
        self.moveToWeightController(vale: 6)
    }
    
    @IBAction func btnSevenAction() {
        self.moveToWeightController(vale: 7)
    }
    
    @IBAction func btnEightAction() {
        self.moveToWeightController(vale: 8)
    }
    
    @IBAction func btnNineAction() {
        self.moveToWeightController(vale: 9)
    }
    
    func moveToWeightController(vale : Int){
        pushController(withName: "WeightInterfaceController", context: vale)
    }
}
