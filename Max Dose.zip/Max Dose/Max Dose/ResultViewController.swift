//
//  ResultViewController.swift
//  Max Dose
//
//  Created by AkifBilal on 15/04/2022.
//

import UIKit

class ResultViewController: UIViewController {

    var selectedMenu = 0
    var selectedWeight = 0
    var selectedPerson = ""
    
    @IBOutlet weak var lblResult: UILabel!
    @IBOutlet weak var lblResultSumary: UILabel!
    
    @IBOutlet weak var lblFormula: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.calculateResult()
    }
    
    func calculateResult(){
        if(selectedMenu == 1){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 36
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/36"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/36"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 36
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/36"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/36"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 500mg /11 carp\nMax for Kids: 300mg"
        } else if(selectedMenu == 2){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 36
                if(val > 5.5){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/36"
                    lblResult.text = "5.5 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/36"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 36
                if(val > 5.5){
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/36"
                    lblResult.text = "5.5 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/36"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 500mg/ 5.5 carps\nMax for Kids: 300mg"
        } else if(selectedMenu == 3){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 36
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/36"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/36"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 36
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/36"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/36"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 400mg /11 carp\nMax for Kids: 300mg"
        } else if(selectedMenu == 4){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 54
                if(val > 7){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/54"
                    lblResult.text = "7 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/54"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 2.0) / 54
                if(val > 7){
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/54"
                    lblResult.text = "7 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 2.0)/54"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 400mg /7 carp\nMax for Kids: 300mg"
        } else if(selectedMenu == 5){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight)) / 9
                if(val > 10){
                    lblFormula.text = "Used Formula\nWeight/9"
                    lblResult.text = "10 Carpules"
                } else {
                    lblFormula.text = "Used Formula\nWeight/9"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 0.6) / 9
                if(val > 10){
                    lblFormula.text = "Used Formula\n(Weight * 0.6)/9"
                    lblResult.text = "10 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 0.6)/9"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 90mg /10 carp\nMax for Kids: 90mg"
        } else if(selectedMenu == 6){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: Det by wt\nMax for Kids: 500mg"
        } else if(selectedMenu == 7){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 3.2) / 72
                if(val > 11){
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = "11 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 3.2)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Kids: 2.0mg/ lb , 300mg"
        } else if(selectedMenu == 8){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 4.0) / 72
                if(val > 8){
                    lblFormula.text = "Used Formula\n(Weight * 4.0)/72"
                    lblResult.text = "8 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 4.0)/72"
                    lblResult.text =  String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 2.7) / 72
                if(val > 8){
                    lblFormula.text = "Used Formula\n(Weight * 2.7)/72"
                    lblResult.text = "8 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 2.7)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 600mg/8 carp\nMax for Kids:400mg"
        } else if(selectedMenu == 9){
            if(selectedPerson == "Adult"){
                let val = (Double(selectedWeight) * 4.0) / 72
                if(val > 8){
                    lblFormula.text = "Used Formula\n(Weight * 4.0)/72"
                    lblResult.text = "8 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 4.0)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            } else {
                let val = (Double(selectedWeight) * 2.7) / 72
                if(val > 8){
                    lblFormula.text = "Used Formula\n(Weight * 2.7)/72"
                    lblResult.text = "8 Carpules"
                } else {
                    lblFormula.text = "Used Formula\n(Weight * 2.7)/72"
                    lblResult.text = String(format: "%.1f", val) + " Carpules"
                }
            }
            lblResultSumary.text = "Max for Adults: 600mg/8 carp\nMax for Kids:400mg"
        }
    }
    
    @IBAction func btnHomeAction(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
}
