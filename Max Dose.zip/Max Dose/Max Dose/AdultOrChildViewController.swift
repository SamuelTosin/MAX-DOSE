//
//  AdultOrChildViewController.swift
//  Max Dose
//
//  Created by AkifBilal on 15/04/2022.
//

import UIKit

class AdultOrChildViewController: UIViewController {

    var selectedMenu = 0
    var selectedWeight = 0
    
    var selectedPerson = "Adult"
    
    @IBOutlet weak var btnAdult: UIButton!
    @IBOutlet weak var btnChild: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(selectedMenu == 7){
            btnChild.isHidden = true
        } else {
            btnChild.isHidden = false
        }
    }
    
    @IBAction func btnAdultAction(_ sender: Any) {
        selectedPerson = "Adult"
        btnAdult.setImage(UIImage.init(named: "radio-checked"), for: .normal)
        btnChild.setImage(UIImage.init(named: "radio-uncheck"), for: .normal)
    }
    
    @IBAction func btnChildAction(_ sender: Any) {
        selectedPerson = "Child"
        btnAdult.setImage(UIImage.init(named: "radio-uncheck"), for: .normal)
        btnChild.setImage(UIImage.init(named: "radio-checked"), for: .normal)
    }
    
    @IBAction func btnNextAction(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ResultViewController") as! ResultViewController
        nextViewController.selectedMenu = selectedMenu
        nextViewController.selectedWeight = selectedWeight
        nextViewController.selectedPerson = selectedPerson
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}
