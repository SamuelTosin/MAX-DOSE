//
//  ViewController.swift
//  Max Dose
//
//  Created by AkifBilal on 15/04/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    @IBAction func btnFirstAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnSecondAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnThirdAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnForthAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnFifthAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnSixthAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnSeventhAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnEighthAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    @IBAction func btnNinthAction(_ sender: UIButton) {
        self.moveToWeightController(vale: sender.tag)
    }
    
    func moveToWeightController(vale : Int){
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "WeightViewController") as! WeightViewController
        nextViewController.selectedMenu = vale
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}
