//
//  WeightViewController.swift
//  Max Dose
//
//  Created by AkifBilal on 15/04/2022.
//

import UIKit

class WeightViewController: UIViewController {

    var selectedMenu = 0
    @IBOutlet weak var txtWeight: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let myColor = UIColor.blue
        txtWeight.layer.borderColor = myColor.cgColor
        txtWeight.layer.borderWidth = 1.0
        
        txtWeight.layer.cornerRadius = 5
    }
    
    @IBAction func btnNextAction(_ sender: Any) {
        if(txtWeight.text != ""){
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "AdultOrChildViewController") as! AdultOrChildViewController
            nextViewController.selectedMenu = selectedMenu
            let weight = Int(txtWeight.text ?? "0")
            nextViewController.selectedWeight = weight ?? 0
            self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
}
